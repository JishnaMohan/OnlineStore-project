from django.contrib import admin
from .models import*


admin.site.register(Book_Signup)
admin.site.register(Category)
admin.site.register(Book_Store)
admin.site.register(Order)
admin.site.register(Cart)
admin.site.register(Wishlist)

