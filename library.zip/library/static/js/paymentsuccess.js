function func(){
    document.getElementById("box").style.display = "block";
}